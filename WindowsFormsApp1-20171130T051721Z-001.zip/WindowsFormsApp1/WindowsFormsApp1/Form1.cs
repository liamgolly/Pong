﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace WindowsFormsApp1
{
    public partial class Form1 : Form
    {
        public int xBallSpeed = 2;
        public int xBallDirection = 1;
        public int yBallSpeed = 2;
        public int yBallDirection = 1;
        public bool P1MoveUp;
        public bool P1MoveDown;
        public bool P2MoveUp;
        public bool P2MoveDown;
        private readonly Timer timer= new Timer();
        public Form1()
        {
            InitializeComponent();
            KeyDown += new KeyEventHandler(Form1_KeyDown);

            timer.Interval = 1;
            timer.Tick += TimerTick;
            timer.Enabled = true;
        }
        void Form1_KeyDown(object sender, KeyEventArgs e)
        { 
            int y = pictureBox1.Location.Y;
            int w = pictureBox2.Location.Y;

            if (e.KeyCode == Keys.Up)
            {
                y -= 7;
                P1MoveUp = true;
                P1MoveDown = false;
            }
            else if (e.KeyCode == Keys.Down)
            {
                y += 7;
                P1MoveDown = true;
                P1MoveUp = false;
            }
            else
            {
                P1MoveUp = false;
                P1MoveDown = false;
            }
            if (e.KeyCode == Keys.W)
            {
                w -= 7;
                P2MoveUp = true;
                P2MoveDown = false;
            }
            else if (e.KeyCode == Keys.S)
            {
                w += 7;
                P2MoveDown = true;
                P2MoveUp = false;
            }
            else
            { 
                P2MoveUp = false;
                P2MoveDown = false;
            }
            pictureBox1.Location = new Point(646, y);
            pictureBox2.Location = new Point(12, w);
        }
        void TimerTick(object sender, EventArgs e)
        {
            int x = pictureBox3.Location.X;
            int y = pictureBox3.Location.Y;
            pictureBox3.Location = new Point(x += xBallSpeed * xBallDirection, y += yBallSpeed * yBallDirection);
            if (y < 0 || y > 465)
            {
                yBallDirection *= -1;
            }
            if (pictureBox3.Bounds.IntersectsWith(pictureBox1.Bounds))
            {
                xBallDirection *= -1;
                if (P1MoveUp == true && yBallDirection == 1) yBallDirection *= -1;
                else if (P1MoveDown == true && yBallDirection == -1) yBallDirection *= -1;
                else yBallDirection *= 1;
            }
            if (pictureBox3.Bounds.IntersectsWith(pictureBox2.Bounds))
            {
                xBallDirection *= -1;
                if (P2MoveUp == true && yBallDirection == 1) yBallDirection *= -1;
                else if (P2MoveDown == true && yBallDirection == -1) yBallDirection *= -1;
                else yBallDirection *= 1;
            }
        }
    }
}
